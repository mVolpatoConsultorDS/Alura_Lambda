export function log (mensagem) {
    console.log('Adicionando log via Funcao', mensagem);
}